//
//  PinViewLineChart.swift
//  TradingJourney
//
//  Created by iMac on 13/06/23.
//
import Charts
import Foundation

class RoundMarkerView: MarkerView {
    
    private var imageView: UIImageView = UIImageView()
    private var path: UIBezierPath!
    private let shapeLayer = CAShapeLayer()
    private let topshapeLayer = CAShapeLayer()
    private var customView = LineCharPinView()
    var width: CGFloat = 0
    var height: CGFloat = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    override func offsetForDrawing(atPoint point: CGPoint) -> CGPoint {
        let offset = -self.bounds.size.height / 2.0
        return CGPoint(x: 0, y: offset)
    }
    
    override func refreshContent(entry: ChartDataEntry, highlight: Highlight) {
        // Customize the content of the marker view based on the selected entry
//        highlight.is
    }
    
    override func draw(context: CGContext, point: CGPoint) {
        super.draw(context: context, point: point)
        offset = offsetForDrawing(atPoint: point)
    }
    
    func setup() {
        let imageSize: CGFloat = 14.0
        imageView = UIImageView(frame: CGRect(x: -imageSize / 2.0, y: -imageSize / 2.0, width: imageSize, height: imageSize))
        let dotImage = UIImage(named: "LineDot")
        imageView.image = dotImage
        
        
        customView = LineCharPinView(frame: CGRect(x: -width / 2.0, y: imageView.frame.midY , width: width, height: height))
                customView.backgroundColor = .clear
        
        addSubview(imageView)
        addSubview(customView)
    }
    
    func setData(date: String, value: String) {
        customView.setupData(date: date, value: value)
    }
    
}
