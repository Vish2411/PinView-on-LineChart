//
//  Class.swift
//  TradingJourney
//
//  Created by iMac on 17/05/23.
//

import Foundation
import UIKit
import Charts

class AxisDateFormatter: NSObject, AxisValueFormatter {
    
    var dateFormatter: DateFormatter
    
    init(dateFormatter: DateFormatter) {
        self.dateFormatter = dateFormatter
    }
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let date = Date(timeIntervalSince1970: value)
        return dateFormatter.string(from: date)
    }
}

class CustomYAxisValueFormatter: NSObject, AxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
            let formattedValue = String(format: "$%.0f   ", value)
            return formattedValue
        }
}

class CustomXAxisValueFormatter: NSObject, AxisValueFormatter {

    let dateFormatter: DateFormatter
    
    override init() {
        dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yy"
        super.init()
    }
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let date = Date(timeIntervalSince1970: value)
        let formattedValue = dateFormatter.string(from: date)
        return formattedValue
    }
}


class CustomYAxisStriValueFormatter: NSObject, AxisValueFormatter {
    private let values: [String]
    
    init(values: [String]) {
        self.values = values
    }
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let index = Int(value)
        if index >= 0 && index < values.count {
            return values[index]
        }
        return ""
    }
}







